== Decryption Instructions ==
1. Extract the contents of this archive into the affected computer, in any folder.
2. private.pem is the RSA2048 private key used in the decryption process. It's crucial to the decryption that it's adjacent to the decryptor application.
3. Run ./app/decryptor.exe with --help argument, AS AN ADMINISTRATOR (if not, it may not be able to decrypt all files).

=== Linux Instructions ===
1. Extract the "linux" folder into the computer.
2. private.pem is the EC key used in the decryption process. It's crucial to the decryption that it's adjacent to the decryptor application.
3. chmod +x decryptor.elf && ./decryptor.elf
4. Read the instructions printed on your screen.


Warning:
Disable your anti-virus, Windows Defender and terminate all other applications that you can.
If multiple computers were affected in the encryption process, we suggest running it one at a time IF computers happen to share any drives.
This may cause a complication in the process as both computers will attempt to decrypt it at the same time.

Note:
Unlike the encryption process, which directly writes to the existing files, the decryptor will create new files out of the encrypted instances.
This requires a manual deletion of the encrypted files in your system or the usage of the "-r" argument.
It's absolutely intended and designed to make sure an error does not wipe your files from the disk.
Make sure all data is intact before deleting the encrypted files.